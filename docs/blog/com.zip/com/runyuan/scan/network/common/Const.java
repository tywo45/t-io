package com.runyuan.scan.network.common;

/**
 * 
 * @author tanyaowu 
 *
 */
public interface Const
{

	public static final int PORT = 20000;
	
	public static final String CHARSET = "utf-8";
	
}
