package com.runyuan.scan.network.packets;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: kleen
 * Date: 2017-04-11
 * Time: 14:19
 */
public class ScanInReqBody extends BaseBody{
    //业务相关，代码被删
}
